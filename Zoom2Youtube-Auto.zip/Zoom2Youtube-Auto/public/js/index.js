$(document).ready(function() {
  console.log("Your JS file is included");
});
